# date-and-time-picker
Jquery plugin witch moment js


 settings..
selectData: default 'now' to set data paste string like '2016-04-05 10:00'  in date format
locale: default 'en' enable any language from moment js
dateFormat: default 'YYYY-MM-DD HH:mm' string in format from moment.js
positionShift: { top: 20, left: 0}
title: 'Select Date and Time'
buttonTitle: 'Select'

